#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h> // For errno global
#include <stdlib.h>//for CHECK MACRO
#define SYSCALL_CS300_TEST2 549
// Macro for custom testing; does exit(1) on failure.
#define CHECK(condition) do{ \
    if (!(condition)) { \
        printf("ERROR: %s (@%d): failed condition \"%s\"\n", __func__, __LINE__, #condition); \
        exit(1);\
    }\
} while(0)

struct array_stats_s {
long min;
long max;
long sum;
};



//#define SYSCALL_CS300_TEST 360 // for a 32 bit system
int main(int argc, char *argv[])
    {
    //int arr1[11]={0,1,2,3,4,5,6,7,8,9,10};

    long arr[11]={0,1,2,3,4,5,6,7,8,9,10};
    long arr2[100];
    for(int i = 0; i<100; i++){
        if(i % 2 ==0){
            arr2[i] = i;
        }
        else{
            arr2[i] = -i;
        }
    }

    long arr3[5] = {-1243, -2432, 342345, 54325235};
    
    long size = 11;
    long size2 = 100;
    long size3 = 5;
    struct array_stats_s example = {0,0,0};
    
    printf("\nTEST 1 - testing with normal values \n");
    printf("\nDiving to kernel level\n\n");
    int result = syscall(SYSCALL_CS300_TEST2,&example,&arr,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    int errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result != -1);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);
    

    example.sum = 0; example.min = 0; example.max = 0;
    printf("\nTEST 2- testing with Null pointer\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,NULL,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 14);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);
    

    example.sum = 0; example.min = 0; example.max = 0;
    printf("\nTEST 3 - testing with Null pointer\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,NULL,&arr,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 14);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);


    example.sum = 0; example.min = 0; example.max = 0;
    size = 0;
    printf("\nTEST 4 - testing with invalid size\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,&arr,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 22);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);


    example.sum = 0; example.min = 0; example.max = 0;
    size = -5;
    printf("\nTEST 5 - testing with invalid size\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,&arr,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 22);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);


    example.sum = 0; example.min = 0; example.max = 0;
    printf("\nTEST 6 - testing with a different set of normal values\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,&arr2,size2);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result != -1);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);


    example.sum = 0; example.min = 0; example.max = 0;
    printf("\nTEST 7 - testing with a different set of normal values\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,&arr3,size3);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result != -1);
    printf("\nsum is %ld. min is %ld. max is %ld", example.sum,example.min,example.max);


    size = 100000;
    example.sum = 0; example.min = 0; example.max = 0;
    printf("\nTEST 8 - testing with invalid size\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST2,&example,&arr,size);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 14);
    printf("\nsum is %ld. min is %ld. max is %ld\n", example.sum,example.min,example.max);

    // We got here?!? PASSED!
    printf("\n********************************\n");
    printf("           PASSED\n");
    printf("********************************\n");
    return 0;
}