#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h> // For errno global
#define SYSCALL_CS300_TEST 548 // for a 64 bit system
//#define SYSCALL_CS300_TEST 360 // for a 32 bit system
int main(int argc, char *argv[])
{
printf("\nDiving to kernel level\n\n");
int result = syscall(SYSCALL_CS300_TEST , 12345);
// Get the error code (if any)
// errno is when a syscall or some library function has an error
// when syscall returns -1, then check errno for specific error
int errorCode = errno;
printf("\nRising to user level w/ result = %d (err #%d)\n\n",
result, errorCode);

return 0;
}