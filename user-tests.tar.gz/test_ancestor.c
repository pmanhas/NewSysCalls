#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h> // For errno global
#include <stdlib.h>//for CHECK MACRO
#define SYSCALL_CS300_TEST 550
// Macro for custom testing; does exit(1) on failure.
#define CHECK(condition) do{ \
    if (!(condition)) { \
        printf("ERROR: %s (@%d): failed condition \"%s\"\n", __func__, __LINE__, #condition); \
        exit(1);\
    }\
} while(0)

#define ANCESTOR_NAME_LEN 16
struct process_info {
long pid; /* Process ID */
char name[ANCESTOR_NAME_LEN]; /* Program name of process */
long state; /* Current process state */
long uid; /* User ID of process owner */
long nvcsw; /* # voluntary context switches */
long nivcsw; /* # involuntary context switches */
long num_children; /* # children process has */
long num_siblings; /* # sibling process has */
};



int main(int argc, char *argv[])
{
    long size = -5;
    struct process_info test[100];
    long numfilled = 0;

    printf("\nTEST 1 - testing for invalid size\n");
    printf("\nDiving to kernel level\n\n");
    int result = syscall(SYSCALL_CS300_TEST,&test,size,&numfilled);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    int errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 22);
    
    size = 5;
    printf("\nTEST 2 - testing for invalid process_info\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST,NULL,size,&numfilled);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 14);


    size = 5;
    printf("\nTEST 3 - tesing for invalid pointer\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST,&test,size,NULL);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 14);



    size = 5;
    printf("\nTEST 4 - testing to see if works for size 5\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST,&test,size,&numfilled);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result !=-1);

    for(int i = numfilled-1; i > -1; i--){
        printf("Idx#: %d   PID: %ld  Name: %s     State: %ld     UID: %ld    #VCSW: %ld     #IVCSW : %ld   #Child: %ld     #Sib: %ld \n",i,test[i].pid, test[i].name,test[i].state, test[i].uid, test[i].nvcsw, test[i].nivcsw, test[i].num_children,test[i].num_siblings);
    }


    size = 1000;
    printf("\nTEST 5 - testing to see if it will get all process and end before size\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST,&test,size,&numfilled);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result !=-1);

    for(int i = numfilled-1; i > -1; i--){
        printf("Idx#: %d   PID: %ld  Name: %s     State: %ld     UID: %ld    #VCSW: %ld     #IVCSW : %ld   #Child: %ld     #Sib: %ld \n",i,test[i].pid, test[i].name,test[i].state, test[i].uid, test[i].nvcsw, test[i].nivcsw, test[i].num_children,test[i].num_siblings);
    }

    size = 0;
    printf("\nTEST 6 - testing for invalid size\n");
    printf("\nDiving to kernel level\n\n");
    result = syscall(SYSCALL_CS300_TEST,&test,size,&numfilled);
    // Get the error code (if any)
    // errno is when a syscall or some library function has an error
    // when syscall returns -1, then check errno for specific error
    errorCode = errno;
    printf("\nRising to user level w/ result = %d (err #%d)\n\n",result, errorCode);
    CHECK(result == -1 && errorCode == 22);


    // We got here?!? PASSED!
    printf("\n********************************\n");
    printf("           PASSED\n");
    printf("********************************\n");

return 0;
}
