#include <linux/kernel.h>
#include <linux/syscalls.h>\

struct array_stats_s {
long min;
long max;
long sum;
};
SYSCALL_DEFINE3(
array_stats, /* syscall name */
struct array_stats_s*, stats, /* where to write stats */
long*, data, /* data to process */
long, size) /* # values in data */
{
// your code here…
    long sum = 0;
    long max = -9223372036854775807 - 1;
    long min = 9223372036854775806 + 1;
    long temp = 0;
    int i = 0;

    if(size <= 0){// making sure size is greater then one. if fail return -EINVAL
        return -EINVAL;
    }

    else{

        for(i = 0; i < size; i++){//loop iterates through the array
            if(copy_from_user(&temp,&data[i],sizeof(long)) != 0){//getting value of array at index i
                return -EFAULT;//return -EFAULT if fail
                
            }
            sum += temp;//summing up all values

            if(temp > max){//updates max if there is a bigger value in the array
                max = temp;
            }

            if(min > temp){//updates min if there is a smaller value in the array
                min = temp;
            } 
        }
        //sends the values of max,min,sum into the arraystats struct. if fails returns -EFAULT
        if(copy_to_user(&stats->min, &min, sizeof(long)) != 0 || copy_to_user(&stats->max, &max, sizeof(long)) != 0 || copy_to_user(&stats->sum, &sum, sizeof(long)) != 0){
            return -EFAULT;
        }

        else{
            return 0;
        }
    } 

}
