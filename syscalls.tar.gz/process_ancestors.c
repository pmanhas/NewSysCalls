#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>
#define ANCESTOR_NAME_LEN 16
struct process_info {
long pid; /* Process ID */
char name[ANCESTOR_NAME_LEN]; /* Program name of process */
long state; /* Current process state */
long uid; /* User ID of process owner */
long nvcsw; /* # voluntary context switches */
long nivcsw; /* # involuntary context switches */
long num_children; /* # children process has */
long num_siblings; /* # sibling process has */
};
SYSCALL_DEFINE3(
process_ancestors, /* syscall name for macro */
struct process_info*, info_array, /* array of process info strct */
long, size, /* size of the array */
long*, num_filled) /* # elements written to array */
{
// your code here…
long i = 0;//iterator variable
int temp_counter = 0;//summation variable
long temp_long = 0;//casting variable
struct task_struct *my_sibling;//position pointer for list of siblings
struct task_struct *my_children;//position pointer for list of children
struct task_struct* task = current;//pointer for current process


if(size <= 0){ // making sure size is greater then one. if fail return -EINVAL
        return -EINVAL;
    }

while(i < size){//loop handles storing information for each process in info_array
    memcpy(&temp_counter,&task->pid,sizeof(task->pid));//storing pid in temp
    temp_long = (long)temp_counter;//converting into long type

    if(copy_to_user(&info_array[i].pid,&temp_long, sizeof(temp_long)) != 0){//copy pid into info array. if fail return -EFAULT
        return -EFAULT;
    }

    if(copy_to_user(&info_array[i].name, &task->comm, sizeof(task->comm)) != 0){//copy process name into info array. if fail return -EFAULT
        return -EFAULT;
    }

    if(copy_to_user(&info_array[i].state, (long*)(&task->state), sizeof(task->state)) != 0){//copy state into info array. if fail return -EFAULT
        return -EFAULT;
    }

    if(copy_to_user(&info_array[i].uid, &task->cred->uid.val, sizeof(task->cred->uid.val)) != 0){//copy uid into info array. if fail return -EFAULT
        return -EFAULT;
    }

    if(copy_to_user(&info_array[i].nvcsw, &task->nvcsw, sizeof(task->nvcsw)) != 0){//copy nvcsw into info array. if fail return -EFAULT
        return -EFAULT;
    }

    if(copy_to_user(&info_array[i].nivcsw, &task->nivcsw, sizeof(task->nivcsw)) != 0){//copy nivcsw into info array. if fail return -EFAULT
        return -EFAULT;
    }

    temp_long = 0;
        list_for_each_entry(my_sibling, &task->sibling, sibling) {//counts number of siblings
            temp_long++;
    }

    if(task != task->parent){//taking count of parent process out of total
        temp_long--;
    }

    if(copy_to_user(&info_array[i].num_siblings, &temp_long, sizeof(temp_long)) != 0){//copy number of siblings into info array. if fail return -EFAULT
        return -EFAULT;
    }

    temp_long = 0;
    list_for_each_entry(my_children, &task->children, sibling) {//counts number of children
        temp_long++;
    }

    

    if(copy_to_user(&info_array[i].num_children, &temp_long, sizeof(temp_long)) != 0){//copy number of children into info array. if fail return -EFAULT
        return -EFAULT;
    }

    i++;
    if(copy_to_user(num_filled, &i, sizeof(i)) != 0){//updates numfilled by one. if fail return -EFAULT
        return -EFAULT;
    }
    i--;

    i++;//updating i by one

    if(task == task->parent){//if at first task by linux end loop
        break;
    }
    task = task->parent;//update task to its parent process
}


return 0;
   
}
